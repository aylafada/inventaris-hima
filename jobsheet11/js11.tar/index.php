<?php

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/koneksi.php';

$totalBarang = $pdo->query("
    SELECT COUNT(*)
    FROM barang
")->fetchColumn();

$totalStok = $pdo->query("
    SELECT COALESCE(SUM(jumlah), 0)
    FROM barang
")->fetchColumn();

$totalDipinjam = $pdo->query("
    SELECT COUNT(*)
    FROM peminjaman
    WHERE status = 'Dipinjam'
")->fetchColumn();

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Inventaris HIMA - Jobsheet 11</title>

    <link
        rel="stylesheet"
        href="<?= BASE_URL ?>/assets/css/style.css"
    >

</head>

<body>

<div class="layout">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>
            Inventaris HIMA
        </h2>

        <p class="sidebar-subtitle">
            Sistem Inventaris
        </p>


        <div class="user-info">

            <strong>
                <?= e($_SESSION['nama']) ?>
            </strong>

            <span>
                <?= e($_SESSION['role']) ?>
            </span>

            <a href="<?= BASE_URL ?>/auth/logout.php">
                Logout
            </a>

        </div>


        <nav>

            <a
                href="<?= BASE_URL ?>/index.php"
                class="active"
            >
                Dashboard
            </a>

            <a href="<?= BASE_URL ?>/barang/list.php">
                Data Barang
            </a>

            <a href="<?= BASE_URL ?>/peminjaman/list.php">
                Peminjaman
            </a>

        </nav>

    </aside>


    <!-- CONTENT -->

    <main class="content">

        <div class="page-header">

            <div>

                <p class="eyebrow">
                    HIMA
                </p>

                <h1>
                    Dashboard Inventaris
                </h1>

                <p>
                    Kelola data barang dan peminjaman inventaris organisasi.
                </p>

            </div>

        </div>


        <!-- SUMMARY -->

        <section class="summary-grid">

            <div class="summary-card">

                <span>
                    Total Barang
                </span>

                <strong>
                    <?= e($totalBarang) ?>
                </strong>

            </div>


            <div class="summary-card">

                <span>
                    Total Stok
                </span>

                <strong>
                    <?= e($totalStok) ?>
                </strong>

            </div>


            <div class="summary-card">

                <span>
                    Sedang Dipinjam
                </span>

                <strong>
                    <?= e($totalDipinjam) ?>
                </strong>

            </div>

        </section>


        <!-- WELCOME -->

        <section class="welcome-card">

            <div>

                <p class="eyebrow">
                    Inventaris HIMA
                </p>

                <h2>
                    Kelola barang organisasi dengan lebih teratur.
                </h2>

                <p>
                    Gunakan menu di sebelah kiri untuk melihat data barang
                    atau mengelola peminjaman inventaris.
                </p>

            </div>


            <a
                href="<?= BASE_URL ?>/barang/tambah.php"
                class="btn-primary"
            >
                + Tambah Barang
            </a>

        </section>

    </main>

</div>


<script src="<?= BASE_URL ?>/assets/js/app.js"></script>

</body>

</html>